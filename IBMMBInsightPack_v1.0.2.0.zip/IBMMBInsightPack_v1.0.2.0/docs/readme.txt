IBM MB Insight Pack 

Contents 

1.  IBM MB Insight Pack 
2.  Installing the IBM MB Insight Pack
3.  IBM MB Insight Pack configuration artifacts 
4.  Configuring the IBM MB Insight Pack 
5.  Log File Agent configuration 
6.  IBM MB Insight Pack Log splitter rules 
7.  IBM MB Insight Pack Log annotation rules 
8.  IBM MB Insight Pack dashboard 
9.  Configuring the IBM MB Insight Pack dashboard 
10. IBM MB Insight Pack References
11. Support

=========================================================================================================================

1. IBM MB Insight Pack 
-----------------------
The IBM MB Insight Pack facilitates data ingestion and metadata searches of IBM Message Broker and IBM Integration Bus log  files in IBM Operations Analytics - Log Analysis to enable faster problem identification.

The IBM MB Insight Pack supports searching and indexing of the following:
 - console logs
    - UNIX/Linux: /var/mqsi/components/broker_name/execution_group_uuid\console.txt 
    - Windows: workpath\components\broker_name\execution_group_uuid\console.txt 
where workpath is the Message Broker defined working directory.
The console.txt log file includes information about the Broker ID, messages from the Message Broker, log record, timestamps, Universally Unique ID for IBM Integration Bus objects, and Java exceptions.

 - Syslog 
    - UNIX/Linux: The syslog is the local error log. The configuration of your UNIX/Linux system determines where the syslog messages are sent.

 - UserTrace Logs 
    - UNIX/Linux: /var/mqsi/common/log 
    - Windows: The default location without a specified integration node work path is C:\ProgramData\IBM\MQSI\Common\log.
	If the path is set with the -w parameter of the mqsicreatebroker command the location is workpath/log.
	The file names reflect the component and subcomponent for which the trace is active.
	For more information about UserTrace logs, see http://www-01.ibm.com/support/knowledgecenter/SSMKHH_10.0.0/com.ibm.etools.mft.doc/ag66260_.htm

The IBM MB Insight Pack can be installed with IBM Operations Analytics - Log Analysis 1.3.0.0 or higher.

Supported IBM Integration Bus versions 

The IBM MB Insight Pack supports the following IBM Integration Bus and IBM WebSphere Message broker versions. IBM Integration Bus was known as IBM WebSphere Message broker until version 8.0.

 - IBM WebSphere Message broker 8.0
 - IBM Integration Bus 9.0
 - IBM Integration Bus 10.0 

=========================================================================================================================

2. Installing the IBM MB Insight Pack 
-------------------------------------
To ingest data and perform searches of the Message Broker log files in IBM Operations Analytics - Log Analysis, you must install the IBM MB Insight Pack.

Before you begin 
You must install IBM Operations Analytics - Log Analysis 1.3.0.0 or higher.

About this task 
The IBM MB Insight Pack is installed by using the pkg_mgmt utility.

Procedure 

1. Upload the IBM MB Insight Pack archive file, MessageBrokerInsightPack_<version>.zip, to the system where IBM Operations  Analytics - Log Analysis is installed.

2. Install the IBM MB Insight Pack by using the pkg_mgmt.sh command:
   <HOME>/IBM/LogAnalysis/utilities/pkg_mgmt.sh -install <path>/MessageBrokerInsightPack_<version>.zip
Where <path> is the path where you saved the IBM MB Insight Pack.

3. (Optional) If you are using the Log File Agent to load the data into IBM Operations Analytics - Log Analysis, deploy the log file agent configuration files with the following command:
   <HOME>/IBM/LogAnalysis/utilities/pkg_mgmt.sh -deploylfa <path>/MessageBrokerInsightPack_<version>.zip
Where <path> is the path where you saved the IBM MB Insight Pack.

=========================================================================================================================

3. IBM MB Insight Pack configuration artifacts 
----------------------------------------------
During IBM MB Insight Pack installation, a number of artifacts are created.

The following artifacts are created when the IBM MB Insight Pack is installed:

 - MessageBroker console log Insight Pack 
   - MsgBrokerSplitter : Splitter file set.
   - MsgBrokerAnnotator : Annotator file set.

 - MessageBroker syslog Insight Pack 
   - MsgBrokerSyslog_Splitter : Splitter file set.
   - MsgBrokerSyslog_Annotator : Annotator file set.
   - MB Dash.app : Dashboard app file

 - MessageBroker User Trace log Insight Pack 
   - MsgBrokerUserTrace_Splitter : Splitter file set.
   - MsgBrokerUserTrace_Annotator : Annotator file set.
   - IIB User Trace Dashboard.app : Dashboard app file .

=========================================================================================================================
   
4. Configuring the IBM MB Insight Pack 
--------------------------------------
To index and search the IBM Message Broker logs files, you must configure the IBM MB Insight Pack. 

Procedure 

1. The default timestamp format that is supported by the Insight Pack for Message Broker console log is yyyy-MM-dd HH:mm:ss.SSS. If the console log timestamp format is different, you must create a new source type. To create a new source type, complete the following steps:

a. In the Administrative settings, open the Data Types tab.
b. Select Create New Source Type.
c. Enter a name for the new source type.
d. Select Enable Splitter>Fileset. In the Fileset field, select MsgBrokerSplitter.
e. Select Enable Annotator>Fileset. In the Fileset field, select MsgBrokerAnnotator.
f. Copy the indexconfig from the Message Broker console log source type and select Edit Index Configuration in the new source type. Paste the indexconfig in to the input box.
g. Modify the timestamp parameter. For example: 

   "timestamp": {
           "dataType": "DATE",
		   "retrievable": true,
		   "retrieveByDefault": true,
		   "sortable": true,
		   "filterable": true,
		   "searchable": true,
		   "source": {
		     "paths": [
			   "metadata.timestamp"
			   ],
			   "dateFormats": [
			     "yyyy-MM-dd HH:mm:ss.SSS"
				]
		      }
			 }, 

h. Click OK to complete and save the new source type.
 
2. The default timestamp format that is supported by the Insight Pack for Message Broker syslog is MMM dd HH:mm:ss yyyy. If the syslog timestamp format is different, you must create a new source type. If the year is not included in the syslog, the IBM MB Insight Pack appends it. To create a new source type, complete the following steps:
a. In the Administrative settings, open the Data Types tab.
b. Select Create New Source Type.
c. Enter a name for the new source type.
d. Select Enable Splitter>Fileset. In the Fileset field, select MsgBrokerSyslog_Splitter
e. Select Enable Annotator>Fileset. In the Fileset field, select MsgBrokerSyslog_Annotator.
f. Copy the indexconfig from the Message Broker syslog source type and select Edit Index Configuration in the new source type. Paste the indexconfig in to the input box.
g. Modify the timestamp parameter. For example:

   "timestamp": } 
           "dataType": "DATE", 
		   "retrievable": true, 
		   "retrieveByDefault": true, 
		   "sortable": true, 
		   "filterable": true, 
		   "searchable": true, 
		   "source": {
		    "paths": [
		      "metadata.timestamp"
			 ],
			 "dateFormats": [
			   "MMM dd HH:mm:ss yyyy"
			  ]
			 }
			},

h. Click OK to complete and save the new source type.

3. The default timestamp format that is supported by the Insight Pack for Message Broker UserTrace log is yyyy-MM-dd HH:mm:ss.S. If the UserTrace log timestamp format is different, you must create a new source type. To create a new source type, complete the following steps:
a. In the Administrative settings, open the Data Types tab.
b. Select Create New Source Type.
c. Enter a name for the new source type.
d. Select Enable Splitter>Fileset. In the Fileset field, select MsgBrokerUserTrace_Splitter
e. Select Enable Annotator>Fileset. In the Fileset field, select MsgBrokerUserTrace_Annotator.
f. Copy the indexconfig from the Message Broker syslog source type and select Edit Index Configuration in the new source type. Paste the indexconfig in to the input box.
g. Modify the timestamp parameter. For example:

   "timestamp": } 
           "dataType": "DATE", 
		   "retrievable": true, 
		   "retrieveByDefault": true, 
		   "sortable": true, 
		   "filterable": true, 
		   "searchable": true, 
		   "source": {
		    "paths": [
		      "metadata.timestamp"
			 ],
			 "dateFormats": [
			   "yyyy-MM-dd HH:mm:ss.S"
			  ]
			 }
			},


h. Click OK to complete and save the new source type.

4. To index console.txt logs, complete the following steps:  
   a. Navigate to the IBM Operations Analytics - Log Analysis settings workspace.
   b. Create a log source for the log file to be monitored. The source type must be Message Broker console log or the source type that is created in step 1.

5. To index syslog, complete the following steps:
   a. Navigate to the IBM Operations Analytics - Log Analysis settings workspace.
   b. Create a log source for the log file to be monitored. The source type must be Message Broker Syslog or the source type that is created in step 2.

6. To index UserTrace logs, complete the following steps:
   a. Navigate to the IBM Operations Analytics - Log Analysis settings workspace.
   b. Create a log source for the log file to be monitored. The source type must be Message Broker UserTrace log or the source type that is created in step 3.

=========================================================================================================================
   
5. Log File Agent configuration 
-------------------------------
You can use the IBM Tivoli Log File Agent to load data into the IBM Operations Analytics - Log Analysis.

The following Log File Agent configuration files will be installed in 
<HOME>/IBM-LFA-6.23/config/lo directory when pkg_mgmt is run with the 
-deploylfa option.

The following Log File Agent configuration files will be installed in <HOME>/IBM-LFA-6.23/config/lo directory when pkg_mgmt is run with the -deploylfa option.
 - WebAccessLogInsightPack-lfadsv.conf - Configuration for the web access log file agent.
 - WebAccessLogInsightPack-lfadsv.fmt - Matches records for the web access log files.

=========================================================================================================================
 
6. IBM MB Insight Pack Log splitter rules 
-----------------------------------------
Splitting describes how IBM Operations Analytics - Log Analysis separates physical log file records in to logical records by using a logical boundary such as time stamp or a new line.

The IBM MB Insight Pack splits log records on new line boundaries. In the following syslog example each line is considered a new log record.

Mar 22 14:23:48 ldp3147 IIB[14903]: [ID 702911 user.info] IBM Integration Bus v9002 
(EAIESB1PRD1BK.EG_COP_RIM_GATEWAY) [Thread 25] (Msg 1/1) BIP2154I< 
Execution group finished with Configuration message.
Mar 22 14:23:49 ldp3147 IIB[14692]: [ID 702911 user.info] IBM Integration Bus v9002 
(EAIESB2PRD1BK.EG_COP_OMD_SVCS1) [Thread 25] (Msg 1/1) BIP3132I< 
The HTTP Listener has started listening on port �7811� for �http� connections.

For console logs, the IBM MB Insight Pack groups log records with multiple lines. For example, the following log record has multiple lines that belong to the exception in the first line. Therefore, the logs are grouped as one with a common time stamp that corresponds to the first record.

2014-12-10 22:04:48.557 18 java.lang.NullPointerExceptiop 
2014-12-10 22:04:48.557 18 at au.net.api.integration.iib.common.Config.<clinit>(Config.java:26) 
2014-12-10 22:04:48.557 18 at java.lang.J9VMInternals.initializeImpl(Native Method) 
2014-12-10 22:04:48.573 18 at java.lang.J9VMInternals.initialize(J9VMInternals.java:237) 

For user trace logs, the IBM MB Insight Pack splits log records based on the timestamp. Each timestamp found by the IBM MB Insight Pack, that matches the UserTrace log timestamp format is considered a new log record, with the following log lines grouped until the next matching timestamp is detected. For example, the following log records match the UserTrace log timestamp format and have multiple log lines. 

2015-02-26 10:29:11.533585   3856   UserTrace BIP3484E:  ��TRAS0018I:
The trace state has changed.
 The new trace state is *=info.��
  An embedded component has written the diagnostic message included here.
  Refer to the appropriate message in the embedded component�s documentation.
  
2015-02-26 10:29:11.806647   3856   UserTrace BIP4040I:  The Execution Group
��Exec_Group�� has processed a configuration message successfully.
  A configuration message has been processed successfully. Any configuration changes have been made and stored persistently.
  No user action required.

=========================================================================================================================
 
7. IBM MB Insight Pack Log annotation rules 
-------------------------------------------
After the log records are split, the logical records are sent to the annotation engine. The engine uses rules to extract important pieces of information that are sent to the indexing engine.

IBM MB Insight Pack console log annotator
The IBM MB Insight Pack annotates the console log records based on the following fields:
 - timestamp
 - message
 - UUID
 - broker_name
 - thread_id
 - logRecord

IBM MB Insight Pack syslog annotator
The IBM MB Insight Pack annotates the syslog records based on the following fields:
 - timestamp
 - SystemName
 - Product
 - Process
 - severity
 - version
 - Broker
 - ExecutionGroup
 - ThreadID
 - MessageGroup
 - MessageID
 - MessageText
 - logRecord

IBM MB Insight Pack UserTrace log annotator
The IBM MB Insight Pack annotates the UserTrace log records based on the following fields:
 - timestamp
 - SystemName
 - Product
 - severity
 - version
 - ExecutionGroup
 - ThreadID
 - MessageID
 - MessageText
 - Node
 - logRecord

=========================================================================================================================
 
8. IBM MB Insight Pack dashboard 
--------------------------------
You can use the IBM MB Insight Pack dashboard example app to visualize data from Message Broker logs.

Use the IBM MB Insight Pack dashboard to find Message Broker-related problems in the shortest time and drilldown into the problem to identify the root cause.

The IBM MB Insight Pack dashboard app for syslog contains the following charts:

 - BIP2001I:Brk start, BIP2228E: Brk Abend
   - Displays broker start and end events.

 - BIP2208I: EG start, BIP2204I: EG Stop
   - Displays execution group start and end events.

 - HTTP Listener Start
   - Displays HTTP listener events.

 - Error, Warning and Info messages
   - Displays the distribution of error, warning, and information logs over time.

The IBM MB Insight Pack dashboard app for UserTrace log contains the following charts:

 - Error 
   - Displays the error count over time. Counting is based on 1 minute intervals. 

 - Which Errors
   - Displays the number of occurrences of each MessageID corresponding to an error message, in 1 minute intervals.

 - Message Flow and Node Error
   - Displays the Nodes and message flows that caused the error messages.

=========================================================================================================================
   
9. Configuring the IBM MB Insight Pack dashboard 
------------------------------------------------
To configure the IBM MB Insight Pack dashboard app, complete the following steps.

1. Copy the MB Dash.app or IIB User Trace Dashboard.app in the <HOME>/IBM/LogAnalysis/AppFramework/Apps/MessageBrokerInsightPack_<version> directory. Save the copied MB Dash.app or IIB User Trace Dashboard.app with a new, unique name. For example, MBDashboard1.app.

2. The dashboard name must be unique. To change the dashboard name, modify the name parameter in the MBDashboard1.app.
 
3. The default log source that is used by the IBM MB Insight Pack dashboard app for syslog is MBSyslog, and for UserTrace is MBUserTrace. You must change the log source for each chart. To change the log source, modify the logsources parameter. For example,

 "logsources": [
                     {
					   "name": "\/MBSyslog",
					   "type": "logSource"
				    }
				],

4. To change the time interval for each chart, modify the filters parameter. For example,

 "filter": {
                       "range": {
					     "timestamp": {
						   "to": "27\/05\/2015 11:22:46.191 +0530, 11:22 AM",
						   "dateFormat": "dd\/MM\/yyyy HH:mm:ss.SSS Z",
						   "from": "27\/05\/2014 11:22:46.191 +0530, 11:22 AM"
						}
					}
				}
   To display the data for the past 2 years in the dashboard, modify the timefilters parameter as follows:
  "filter": {
                       "timefilters": {
				"granularity": "year",
				"lastnum": 2,
				"type": "relative"
				       }
					}

5. Save the changes. To see the new dashboard, refresh the Search Dashboards pane on IBM Operations Analytics - Log Analysis UI. 

=========================================================================================================================

10. IBM MB Insight Pack References 
----------------------------------
Important references for your IBM MB Insight Pack.


IBM Integration Bus Version 10.0 documentation: http://www-01.ibm.com/support/knowledgecenter/SSMKHH_10.0.0/ com.ibm.etools.msgbroker.helphome.doc/help_home_msgbroker.html

=============================================================================================================

11. Support 
-----------

To get support from the IBM support team, you can open a Problem Management Record (PMR).

When you open a PMR to report an Insight Pack specific issue, the following information must be included in the PMR:

 - Insight Pack and product information
    - Basic Insight Pack and product information.

 - Insight Pack name
    - The name of the Insight Pack.

 - Insight Pack version
    - The Insight Pack version.

 - Product name
    - The product name.

 - Product version
    - The version of product on which you are using the Insight Pack.

 - Product log file name
    - The product log file name specific to the issue.

Provide details for the issue that you are reporting. For example:
 - Include sample log files, which are used against this insight pack.
 - Provide a screen capture of the error message that is generated when you use the Insight Pack.
 - Describe the specific use case scenarios when the problem occurred while you were using the Insight Pack.
 - Include IBM Operations Analytics - Log Analysis log files, such as GenericReceiver.log, or UnityApplication.log, for the problem window. 

